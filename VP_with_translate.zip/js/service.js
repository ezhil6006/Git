function configData() {
    return $.ajax({
        type: "GET",
        url: "config.json",
	    dataType: "json",
        async: false
    }).responseText;
}

var hello = JSON.parse(configData());

console.log(hello[0].RESTURL);
console.log(hello[0].ServiceName);

/*function onDataGet(data){
	hello = data;
	console.log(hello);
}*/

VolpayApp.service('GlobalService', function(){
	 var data = {};
	 data.fileListId = -1;
	 data.UniqueRefID = -1;
	return data;
});
