//'use strict';

VolpayApp.controller('DashboardController', function ($rootScope, $scope, $http, $timeout) {
	$scope.$on('$viewContentLoaded', function () {
		// initialize core components
		Metronic.initAjax();
	});

	// set sidebar closed and body solid layout mode
	$rootScope.settings.layout.pageBodySolid = true;
	$rootScope.settings.layout.pageSidebarClosed = false;
});

VolpayApp.controller('dashboardDataCtrl', function ($scope, $http) {
	$http.get('homedata.json')
	.then(function (res) {
		$scope.data1 = res.data;

	});
	return function (exception, cause) {
		exception.message += ' (caused by "' + cause + '")';
		throw exception;
	};
});

VolpayApp.controller('GaugeCtrl', function ($scope, $http, $timeout) {

	$http.get('gauge.json').success(function (data, status) {

		$scope.value = data.numofmessage;
		$scope.upperLimit = data.upperLimit;
		$scope.lowerLimit = data.lowerLimit;
		$scope.unit = data.unit;
		$scope.precision = data.precision;
		$scope.ranges = data.ranges;
		console.log(data);
	});

});

VolpayApp.controller('d3ChartCtrl', function ($scope, $http, $timeout) {

$http.get('chartData.json').success(function (data) {
	
/*   var testdata = [
        {key: "One", y: 5, color: "red"},
        {key: "Two", y: 2},
        {key: "Three", y: 9},
        {key: "Four", y: 7},
        {key: "Five", y: 4},
        {key: "Six", y: 3},
        {key: "Seven", y: 0.5}
    ];
    var testdata2 = [
        {key: "One", y: 5},
        {key: "Two", y: 2},
        {key: "Three", y: 9},
        {key: "Four", y: 7},
        {key: "Five", y: 4},
        {key: "Six", y: 3},
        {key: "Seven", y: 0.5}
    ]; 
 */
	var testdata = data[0].Inbound_Payment;
		$scope.testdata = data[0].Inbound_Payment;

	var testdata2 = data[1].MOP;
	$scope.testdata2 = data[1].MOP;
	
	
    var height = 400;
    var width = 400;

    nv.addGraph(function() {
        var chart = nv.models.pieChart()
            .x(function(d) { return d.key })
            .y(function(d) { return d.y })
			.showLegend(false)
			//.legendPosition("right")
			.showLabels(true)
			.donut(true)
			.labelType('percent')
            .valueFormat(d3.format('%'))
			.labelsOutside(true)
			.labelSunbeamLayout(true)
            .width(width)
			.title("Total Inbound")	
            .height(height);

        d3.select("#test1")
            .datum(testdata)
            //.transition().duration(1200)
            .attr('width', width)
            .attr('height', height)
            .call(chart);

        return chart;
    });

		
	
	
    nv.addGraph(function() {
        var chart = nv.models.pieChart()
            .x(function(d) { return d.key })
            .y(function(d) { return d.y })
            //.labelThreshold(.08)
            .showLabels(false)
            .color(d3.scale.category20().range().slice(8))
            //.growOnHover(false)
            .labelType('value')
			.labelsOutside(false)
			.labelSunbeamLayout(true)
            .width(width)
            .height(height);

	
        // make it a half circle
       /* chart.pie
            .startAngle(function(d) { return d.startAngle/2 -Math.PI/2 })
	   .endAngle(function(d) { return d.endAngle/2 -Math.PI/2 });*/

        // MAKES LABELS OUTSIDE OF DONUT
        //chart.pie.donutLabelsOutside(true).donut(true);

        d3.select("#test2")
            .datum(testdata2)
            //.transition().duration(1200)
            .attr('width', width)
            .attr('height', height)
            .call(chart);

        // disable and enable some of the sections
       // var is_disabled = false;
     /*   setInterval(function() {
            chart.dispatch.changeState({disabled: {2: !is_disabled, 4: !is_disabled}});
            is_disabled = !is_disabled;
	 }, 3000);*/

        return chart;
    });

});	
	
	/*$http.get('chartData.json').success(function (data, status) {

		var testdata1 = data[0].Inbound_Payment;
		$scope.testdata1 = data[0].Inbound_Payment;

		var testdata = data[1].MOP;
		$scope.testdata = data[1].MOP;

		var width = 230;
		var height = 230;
		nv.addGraph(function () {
			var chart = nv.models.pie()
				.x(function (d) {
					return d.key;
				})
				.y(function (d) {
					return d.y;
				})
				.width(width)
				.height(height)
				.labelType(function (d, i, values) {
					return values.key + ':' + values.value;
				})
				.valueFormat(d3.format('%'));
			d3.select("#test1")
			.datum([testdata])
			.transition().duration(1200)
			.attr('width', width)
			.attr('height', height)
			.call(chart);
			return chart;
		});
		nv.addGraph(function () {
			var chart = nv.models.pie()
				.x(function (d) {
					return d.key;
				})
				.y(function (d) {
					return d.y;
				})
				.width(width)
				.height(height)
				.labelType('percent')
				.valueFormat(d3.format('%'))
				.donut(true);
			d3.select("#test2")
			.datum([testdata1])
			.transition().duration(1200)
			.attr('width', width)
			.attr('height', height)
			.call(chart);
			return chart;
		});

	}); */

});