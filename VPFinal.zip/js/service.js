VolpayApp.service('GlobalService', function(){
	 var data = {};
	 data.fileListId = -1;
	 
	 
	 data.f1=function(){
		 // alert("ser fun")
	}
	return data;
});
