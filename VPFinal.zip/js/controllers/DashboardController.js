//'use strict';

VolpayApp.controller('DashboardController', function($rootScope, $scope, $http, $timeout) {
    $scope.$on('$viewContentLoaded', function() {
        // initialize core components
        Metronic.initAjax();
    });

    // set sidebar closed and body solid layout mode
    $rootScope.settings.layout.pageBodySolid = true;
    $rootScope.settings.layout.pageSidebarClosed = false;
});


VolpayApp.controller('dashboardDataCtrl', function($scope, $http) {
  $http.get('homedata.json')
       .then(function(res){
          $scope.data1 = res.data;

        });
        return function(exception, cause) {
            exception.message += ' (caused by "' + cause + '")';
            throw exception;
          };
});

 VolpayApp.controller('GaugeCtrl', function ($scope,$http, $timeout) {

        $http.get('gauge.json').success(function(data, status) {

                        $scope.value = data.numofmessage;
                        $scope.upperLimit = data.upperLimit;
                        $scope.lowerLimit = data.lowerLimit;
                        $scope.unit =data.unit;
                        $scope.precision =data.precision;
                        $scope.ranges =data.ranges;
                     console.log(data);
              });



    });
