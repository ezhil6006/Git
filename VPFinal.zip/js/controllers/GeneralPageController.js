
/* Setup general page controller */
VolpayApp.controller('GeneralPageController', ['$rootScope', '$scope', 'settings', function ($rootScope, $scope, settings) {
			$scope.$on('$viewContentLoaded', function () {
				// initialize core components
				Metronic.initAjax();

				// set default layout mode
				$rootScope.settings.layout.pageBodySolid = false;
				$rootScope.settings.layout.pageSidebarClosed = false;
			});
		}
	]);

VolpayApp.service('resArr', function () {

	var x;
	// var resultArr = [];
	this.method1 = function (arr) {
		x = arr;
	};
	this.method2 = function () {

		return x;

	}

});

VolpayApp.controller('detailCtrl', function ($scope, $filter, $http, $location, resArr,GlobalService) {

	$http.get('filelist.json').success(function (data, status) {

		$scope.datas = data;

	});
	
	
	$scope.clickRefId = function(id){
        GlobalService.fileListId = id; 
		GlobalService.f1();
		$location.path('page3')		
	}
	

});

VolpayApp.controller('page3Ctrl',function($scope,$http,GlobalService){
	 $scope.refId = GlobalService.fileListId;
	 
	 $http.get('filelist.json').success(function (data, status) {

		$scope.datas = data;

	});
});



