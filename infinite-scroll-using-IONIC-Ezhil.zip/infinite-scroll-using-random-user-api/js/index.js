angular.module('ionicApp', ['ionic'])

.factory('PersonService', function($http){
	//var BASE_URL = "http://api.randomuser.me/";
	var items = [];
	
	return {
		GetFeed: function(){
			return $http.get('service.php?start=0&count=10').then(function(response){
				items = response.data;
				return items;
			});
		},
		GetNewUsers: function(val1,val2){
			console.log('service.php?start='+val1+'&count='+val2);
			return $http.get('service.php?start='+val1+'&count='+val2).then(function(response){
				items = response.data;
				console.log(items)
				return items;
			});
		}
	}
})

.controller('MyCtrl', function($scope, $timeout, PersonService) {
  $scope.items = [];
  
  PersonService.GetFeed().then(function(items){
	$scope.items = items;
  });
  var hh=10;
  $scope.loadMore = function(){
    PersonService.GetNewUsers(hh,10).then(function(items) {
      $scope.items = $scope.items.concat(items);	  
      $scope.$broadcast('scroll.infiniteScrollComplete');
    });
	hh=hh+10;
  };
  
});