A Pen created at CodePen.io. You can find this one at http://codepen.io/andrewmcgivery/pen/emEOQy.

 Example using ion-refresher for the "pull to refresh" effect

Forked from [Ionic](http://codepen.io/ionic/)'s Pen [Pull To Refresh: Nightly](http://codepen.io/ionic/pen/mqolp/).

Forked from [Ionic](http://codepen.io/ionic/)'s Pen [Pull To Refresh: Nightly](http://codepen.io/ionic/pen/mqolp/).