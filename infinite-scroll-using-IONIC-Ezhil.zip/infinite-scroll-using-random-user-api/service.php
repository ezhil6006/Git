<?php
    //connect to mysql db
    $con = mysql_connect("localhost","root","") or die('Could not connect: ' . mysql_error());
    //connect to the employee database
    mysql_select_db("kyaschool", $con);
	$start=$_GET['start'];
	$count=$_GET['count'];
	$query="select * from file_rest limit $start,$count";
	$result=mysql_query($query);
	$rows = array();
	while($r = mysql_fetch_assoc($result)) {
    $rows[] = $r;
	}
	print json_encode($rows);
	
	
   /*  //read the json file contents
    $jsondata = file_get_contents('file.json');
   // echo $jsondata;
    //convert json object to php associative array
    $data = json_decode($jsondata, true);
	for($i=0;$i<count($data);$i++){
		$OfficeID=$data[$i]['OfficeID'];
		$BranchID=$data[$i]['BranchID'];
		$UniqueInstructionReference=$data[$i]['UniqueInstructionReference'];
		$SourceChannel=$data[$i]['SourceChannel'];
		$SourceMessage=$data[$i]['SourceMessage'];
		$EntryDate=$data[$i]['EntryDate'];
		$FileStatus=$data[$i]['FileStatus'];
		$Total_Number_of_Payments=$data[$i]['Total Number of Payments'];
		$PaymentsCompleted=$data[$i]['PaymentsCompleted'];
		$PaymentsRejected=$data[$i]['PaymentsRejected'];
		$PaymentsPending=$data[$i]['PaymentsPending'];
		$FileProcessingServer=$data[$i]['FileProcessingServer'];
		$FileHash=$data[$i]['FileHash'];
		$Description=$data[$i]['Description'];		
		$Currency=$data[$i]['CurrencyWiseSum'][0]['Currency'];
		$TotalAmount=$data[$i]['CurrencyWiseSum'][0]['TotalAmount'];
		$sql = "INSERT INTO `kyaschool`.`file_rest` (`OfficeID`, `BranchID`, `UniqueInstructionReference`, `SourceChannel`, `EntryDate`, `FileStatus`, `Total Number of Payments`, `PaymentsCompleted`, `PaymentsRejected`, `PaymentsPending`, `FileProcessingServer`, `FileHash`, `Description`, `Currency`, `TotalAmount`) VALUES ('$OfficeID', '$BranchID', '$UniqueInstructionReference', '$SourceChannel', '$EntryDate', '$FileStatus', '$Total_Number_of_Payments', '$PaymentsCompleted', '$PaymentsRejected', '$PaymentsPending', '$FileProcessingServer', '$FileHash', '$Description', '$Currency', '$TotalAmount');";
			if(!mysql_query($sql,$con))
			{
				die('Error : ' . mysql_error());
			}
	} */
    /* 
    //get the employee details
    $id = $data['empid'];
    $name = $data['personal']['name'];
    $gender = $data['personal']['gender'];
    $age = $data['personal']['age'];
    $streetaddress = $data['personal']['address']['streetaddress'];
    $city = $data['personal']['address']['city'];
    $state = $data['personal']['address']['state'];
    $postalcode = $data['personal']['address']['postalcode'];
    $designation = $data['profile']['designation'];
    $department = $data['profile']['department'];
    
    //insert into mysql table
    $sql = "INSERT INTO tbl_emp(empid, empname, gender, age, streetaddress, city, state, postalcode, designation, department)
    VALUES('$id', '$name', '$gender', '$age', '$streetaddress', '$city', '$state', '$postalcode', '$designation', '$department')";
    if(!mysql_query($sql,$con))
    {
        die('Error : ' . mysql_error());
    } */
?>