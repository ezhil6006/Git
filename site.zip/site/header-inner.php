<!--// Header -->
		<div class="header">
			<!--// header container -->
			 <div class="container">
				<!-- header left -->
				<div class="col-sm-3">
					<div class="logo">
						<a href="index.php">
						<?php 
						if(($actual_filename=="index.php")||($actual_filename==""))
						{
							echo '<img src="images/logo.png" alt="kyaschool.com" class="img-responsive" />';
						}
						else
						{
							echo '<img src="images/logo.png" alt="kyaschool.com" width="211" height="110" class="img-responsive" />';
						}
						?>
						</a>
					</div>
				</div>
				<?php include("menu.php");?>
				
			 </div>
			<!-- header container //-->
		</div>
	<!-- Header /-->