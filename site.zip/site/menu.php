<!-- header right -->
				<div class="col-sm-9">
					<!-- Login and Register -->
					<div class="row log-reg text-right phone-center">
						<a href="javascript:void(0);"> 
							<i class="fa fa-sign-out"></i> Login
						</a>
						
						<a href="javascript:void(0);"> 
							<i class="fa fa-pencil-square-o"></i> Register
						</a>
					</div>
					
					<!-- Main Menu -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
					  </button>
					</div>
					
					<div id="navbar" class="collapse navbar-collapse pull-right">
					  <ul class="nav navbar-nav">
						<li <?php echo compareURL("index.php",$actual_filename); if($actual_filename==''){echo 'class="active"';}?>><a href="index.php">Home</a></li>
						<li <?php echo compareURL("about-us.php",$actual_filename); ?>><a href="about-us.php">About Us </a></li>
						<li><a href="javascript:void(0);">Blog </a></li>
						<li><a href="javascript:void(0);">Add A School </a></li>
						<li><a href="javascript:void(0);">Contact Us </a></li>						
					  </ul>
					</div>
				</div>