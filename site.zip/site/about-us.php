<?php include("header.php"); ?>	
  <body>
	<?php include("header-inner.php"); ?>		
	<!--// Home banner -->
	<div class="home-banner2">
	  <h1>About Us</h1>
      	</div>
	<!-- Home banner //-->
	
	
	<!--// Home About -->
		
	<!-- Home About //-->
	
	
	<!--// Home features -->
		<div class="inner-features">
			<div class="inner-main">
              <div class="inner-left">
                <p>KYAschool.com is run by a group of people – both paid and unpaid – who care deeply about school education in India. Mostly parent of school going children, these individuals dig out facts and information about schools, and make them available to the public through this website.We are always on the lookout to connect and work with like-minded individuals who can offer insight and information into schools and schooling in India.              </p>
                <p>&nbsp;</p>
              </div>
              <div class="inner-add"><img src="images/ads/small.jpg"></div>
            </div>
            <div class="clearfix"></div>
		</div>
	<!-- Home features //-->
	<div class="medium-adds">
		<div class="container all-center">
			<a href="javascript:void(0);">
				<img src="images/ads/medium.jpg" alt="add" class="img-responsive" />
			</a>
		</div>
	</div>
<?php include("footer.php"); ?>