	<!--// footer -->
	<div class="footer">
		<div class="container">
			<div class="col-sm-5">
				<h4>Quick Links </h4>
				<ul class="inline cf">
					<li><a href="javascript:void(0)"> <i class="fa fa-angle-right"></i> About Us </a> </li>
					<li><a href="javascript:void(0)"> <i class="fa fa-angle-right"></i> Privacy </a> </li>
					<li><a href="javascript:void(0)"> <i class="fa fa-angle-right"></i> Blog </a> </li>
					<li><a href="javascript:void(0)"> <i class="fa fa-angle-right"></i> Terms of Use </a> </li>
					<li><a href="javascript:void(0)"> <i class="fa fa-angle-right"></i> Add a School </a> </li>
					<li><a href="javascript:void(0)"> <i class="fa fa-angle-right"></i> Guidelines for reviewing a school </a> </li>
					<li><a href="javascript:void(0)"> <i class="fa fa-angle-right"></i> Contact Us</a> </li>
				</ul>
			</div>
			
			<div class="col-sm-4" data-view="line-v">
				<h4>Sign up for email updates</h4>
				 <form class="navbar-form" role="subscribe">
					<div class="form-group">
					  <input type="text" class="form-control" placeholder="Your Email Address">
					</div><br />
					<button type="submit" class="btn btn-primary">Subscribe</button>
				  </form>
			</div>
			
			<div class="col-sm-3">
				<h4>Connect with us</h4>
				<ul class="social">
					<a href="javascript" class="fb"> <i class="fa fa-facebook"></i></a>
					<a href="javascript" class="tw"> <i class="fa fa-twitter"></i> </a>
					<a href="javascript" class="gplus"> <i class="fa fa-google-plus"></i></a>
					<a href="javascript" class="youtube"> <i class="fa fa-youtube"></i></a>
				<ul>
			</div>
			
		</div>
	</div>
	<div class="clear"></div>
	
	<div class="footer-bottom text-center">
		<p>Copyright &copy; 2015  Kyaschool, All Rights Reserved</p>
	</div>
	<!-- footer //-->
	


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.js"></script>
   
  </body>
</html>
