<?php include("header.php"); ?>	
  <body>
	<?php include("header-inner.php"); ?>		

<?php include("footer.php"); ?>