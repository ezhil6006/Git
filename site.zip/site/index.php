<?php include("header.php"); ?>	
  <body>
	<?php include("header-inner.php"); ?>		
	<!--// Home banner -->
	<div class="home-banner">
		<div class="container">
			<form class="navbar-form banner-search" role="search">
				<div class="col-lg-12">
					<div class="input-group">
					  <input type="text" class="form-control" placeholder="Search for...">
					  <span class="input-group-btn">
						<button class="btn btn-default btn-orange" type="button">SEARCH</button>
					  </span>
					</div><!-- /input-group -->
			  </div><!-- /.col-lg-6 -->
				</form>
		</div>
	</div>
	<!-- Home banner //-->
	
	
	<!--// Home About -->
		<div class="container" data-view="gutter">
			<div class="col-md-9 text-center">
				<h3>Welcome to Kyaschool</h3>
				<p><a href="#javascript:void(0);" title="kyaschool">KYAschool.com</a> is run by a group of people – both paid and unpaid – who care deeply about school education in India. Mostly parent of school going children, these individuals dig out facts and information about schools, and make them available to the public through this website.We are always on the lookout to connect and work with like-minded individuals who can offer insight and information into schools and schooling in India.</p>
			</div>
			
			<div class="col-md-3 tab-center">
				<a href="javascript:void(0);">
					<img src="images/ads/small.jpg" alt="lorem ipsum" class="img-responsive" />
				</a>
			</div>
		</div>
	<!-- Home About //-->
	
	
	<!--// Home features -->
		<div class="home-features">
			<div class="container all-center">
				
				<div class="col-sm-6 col-md-3" data-view="single">
					<img src="images/family.png" alt="lorem" class="img-responsive" />
					<h4>For families</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
				</div>
				
				<div class="col-sm-6 col-md-3" data-view="single">
					<img src="images/school.png" alt="lorem" class="img-responsive" />
					<h4>For schools</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
				</div>
				
				<div class="col-sm-6 col-md-3" data-view="single">
					<img src="images/review.png" alt="lorem" class="img-responsive" />
					<h4>Write a review</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
				</div>
				
				<div class="col-sm-6 col-md-3" data-view="single">
					<img src="images/search-address.png" alt="lorem" class="img-responsive" />
					<h4>Search by address</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
				</div>
				
			</div>
		</div>
	<!-- Home features //-->
	
	<div class="medium-adds">
		<div class="container all-center">
			<a href="javascript:void(0);">
				<img src="images/ads/medium.jpg" alt="add" class="img-responsive" />
			</a>
		</div>
	</div>
	
	<!--// Home testimonial -->
		<div class="container testimonial">
			<div class="row text-center">
				<h4>Testimonials</h4>
			</div>
			<div class="row">
                    <div class="col-md-12" data-wow-delay="0.2s">
                        <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                            <!-- Bottom Carousel Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#quote-carousel" data-slide-to="0" class="active"><img class="img-responsive " src="https://s3.amazonaws.com/uifaces/faces/twitter/brad_frost/128.jpg" alt="">
                                </li>
                                <li data-target="#quote-carousel" data-slide-to="1"><img class="img-responsive" src="https://s3.amazonaws.com/uifaces/faces/twitter/rssems/128.jpg" alt="">
                                </li>
                                <li data-target="#quote-carousel" data-slide-to="2"><img class="img-responsive" src="https://s3.amazonaws.com/uifaces/faces/twitter/adellecharles/128.jpg" alt="">
                                </li>
                            </ol>

                            <!-- Carousel Slides / Quotes -->
                            <div class="carousel-inner text-center">

                                <!-- Quote 1 -->
                                <div class="item active">
                                    <blockquote>
                                        <div class="row">
                                            <div class="col-sm-8 col-sm-offset-2">

                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. !</p>
                                                <small>Name will come here</small>
                                            </div>
                                        </div>
                                    </blockquote>
                                </div>
                                <!-- Quote 2 -->
                                <div class="item">
                                    <blockquote>
                                        <div class="row">
                                            <div class="col-sm-8 col-sm-offset-2">

                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </p>
                                                <small>Name will come here</small>
                                            </div>
                                        </div>
                                    </blockquote>
                                </div>
                                <!-- Quote 3 -->
                                <div class="item">
                                    <blockquote>
                                        <div class="row">
                                            <div class="col-sm-8 col-sm-offset-2">

                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. .</p>
                                                <small>Name will come here</small>
                                            </div>
                                        </div>
                                    </blockquote>
                                </div>
                            </div>

                            <!-- Carousel Buttons Next/Prev -->
                            <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
                            <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
                        </div>
                    </div>
                </div>
		</div>
	<!-- Home testimonial //-->
	
	<!--// home clients -->
	<div class="clients">
		<div class="container all-center">
			<div class="col-sm-3">
				<a href="javascript:void(0);">
					<img src="images/clients/1.jpg" alt="" class="img-responsive" />
				</a>
			</div>
			<div class="col-sm-3">
				<a href="javascript:void(0);">
					<img src="images/clients/2.jpg" alt="" class="img-responsive" />
				</a>
			</div>
			<div class="col-sm-3">
				<a href="javascript:void(0);">
					<img src="images/clients/3.jpg" alt="" class="img-responsive" />
				</a>
			</div>
			<div class="col-sm-3">
				<a href="javascript:void(0);">
					<img src="images/clients/4.jpg" alt="" class="img-responsive" />
				</a>
			</div>
		</div>
	</div>
	<!-- home clients //-->
<?php include("footer.php"); ?>