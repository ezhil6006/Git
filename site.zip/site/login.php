<?php include("header.php"); ?>	
<body>
	<?php include("header-inner.php"); ?>		
	<!--// Home banner -->
	<div class="home-banner2">
		<h1>Login</h1>
	</div>
	<!-- Home banner //-->


	<!--// Home About -->

	<!-- Home About //-->


	<!--// Home features -->
	<div class="inner-features">
		<div class="inner-main">
			<div class="login-left">
				<ul class="form2">
					<li>
						<p>Login Type </p>

						<form name="form" id="form" action="" method="POST">

							<select name="jumpMenu" id="jumpMenu" onChange="MM_jumpMenu('parent',this,0)" class="textb-cont2">
								<option value="Parents">Parents </option>
								<option value="Teacher">Teacher</option>
								<option value="Student">Student</option>
							</select>

						</li>
						<li>
							<p>E-Mail Address</p>
							<input name="email" type="text" class="textb-cont"/>
						</li>
						<li>
							<p>Password</p>
							<input name="password" type="password" class="textb-cont"/>
						</li>        
						<li>
							<p>&nbsp;</p>
							<input name="loginSubmit" type="submit" class="submit" id="login" value="LOGIN" />
						</li>
						<li>
							<p>&nbsp;</p>
						</form>
						<a href="forgotten-password.html" class="menu-u-14">Forgot Password?</a>        </li>
				</ul>
			</div>
			<div class="login-right">

				<h1>New User? Register Now</h1>
				<p>By creating an account you will be able to review & rate any school according to their facilities & activities carried out. You would also be able to state names of outstanding teachers of the respective schools.</p>
				<input name="button2" type="button" class="submit2" id="button2" value="REGISTER NOW" />
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
	<!-- Home features //-->
	<div class="medium-adds">
		<div class="container all-center">
			<a href="javascript:void(0);">
				<img src="images/ads/medium.jpg" alt="add" class="img-responsive" />
			</a>
		</div>
	</div>

	<?php include("footer.php"); ?>
<?php
	if(isset($_POST['loginSubmit']))
	{
		if(($_POST['email']!='')&&($_POST['password']!=''))
		{

			if(($_POST['email']=='test')&&($_POST['password']=='test'))
			{
				echo '<script language="javascript">window.location.href="about-us.php"</script>';
			}
			else
			{
				echo '<script language="javascript">alert("Please check you login details");</script>';
				echo '<script language="javascript">window.location.href="login.php"</script>';
			}
		}
		else{
			echo '<script language="javascript">alert("Please enter your login details then submit");</script>';
				echo '<script language="javascript">window.location.href="login.php"</script>';
		}
	}
?>	