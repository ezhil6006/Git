VolpayApp.service('GlobalService', function(){
	 var data = {};
	 data.fileListId = -1;
	 data.UniqueRefID = -1;


	return data;
});
