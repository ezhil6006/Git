
/* Setup general page controller */
VolpayApp.controller('GeneralPageController', ['$rootScope', '$scope', 'settings', function($rootScope, $scope, settings) {
    $scope.$on('$viewContentLoaded', function() {   
    	// initialize core components
    	Metronic.initAjax();

    	// set default layout mode
        $rootScope.settings.layout.pageBodySolid = false;
        $rootScope.settings.layout.pageSidebarClosed = false;
    });
}]);



VolpayApp.service('resArr', function(){

var x;
   // var resultArr = [];
    this.method1 = function(arr)
    {
      x = arr;
    };
    this.method2 = function()
    {

       return x;

    }



});

/*
VolpayApp.controller('detailCtrl', function ($scope, $filter, $http, $location, resArr,GlobalService) {

	$http.get('filelist.json').success(function (data, status) {

		$scope.datas = data;

	});

	$scope.clickRefId = function(id){
        GlobalService.fileListId = id; 

		$location.path('page3')		
	}


});
*/

VolpayApp.controller('detailCtrl', function ($scope, $filter, $http, $location, resArr,GlobalService) {

	$http.get('filelist.json').success(function (data, status) {

		$scope.datas = data;

	});

	$scope.clickRefId = function(id){
        GlobalService.fileListId = id;

		$location.path('page3')
	}

	$scope.search= function(row){

	     return !!((row.uniquerefnumber.indexOf($scope.searchText || '') !== -1 || row.clientid.indexOf($scope.searchText || '') !== -1 || row.clientname.indexOf($scope.searchText || '') !== -1 || row.filename.indexOf($scope.searchText || '') !== -1 ));

	}


});


VolpayApp.controller('page3Ctrl',function($scope,$http,$location,GlobalService){
	 $scope.refId = GlobalService.fileListId;

	 $http.get('filelist.json').success(function (data, status) {

		$scope.datas = data;

	});

		console.log(GlobalService);

		$scope.clickReferenceID = function(id,UniqueRefID){
        GlobalService.fileListId = id;
        GlobalService.UniqueRefID = UniqueRefID;
		$location.path('page4')
	}


});


		VolpayApp.controller('listdata',function($scope, $http){
	$scope.users = []; //declare an empty array
	$http.get("mockJson/mock.json").success(function(response){ 
		$scope.users = response;  //ajax request to fetch data into $scope.data
	});
	
	$scope.sort = function(keyname){
		$scope.sortKey = keyname;   //set the sortKey to the param passed
		$scope.reverse = !$scope.reverse; //if true make it false and vice versa
	}
});



VolpayApp.controller('page4Ctrl',function($scope,$http,$location,GlobalService){
	 $scope.refId = GlobalService.fileListId;
	 $scope.UniqueRefID = GlobalService.UniqueRefID;

	 $http.get('filelist.json').success(function (data, status) {

		$scope.datas = data;

	});

	$scope.clickRefId = function(id){
            GlobalService.fileListId = id;
    		$location.path('page3')
    	}

});



function MyController($scope) {
	
  $scope.currentPage = 1;
  $scope.pageSize = 10;
  $scope.meals = [];

  var dishes = [
    'noodles',
    'sausage',
    'beans on toast',
    'cheeseburger',
    'battered mars bar',
    'crisp butty',
    'yorkshire pudding',
    'wiener schnitzel',
    'sauerkraut mit ei',
    'salad',
    'onion soup',
    'bak choi',
    'avacado maki'
  ];
  var sides = [
    'with chips',
    'a la king',
    'drizzled with cheese sauce',
    'with a side salad',
    'on toast',
    'with ketchup',
    'on a bed of cabbage',
    'wrapped in streaky bacon',
    'on a stick with cheese',
    'in pitta bread'
  ];
  for (var i = 1; i <= 100; i++) {
    var dish = dishes[Math.floor(Math.random() * dishes.length)];
    var side = sides[Math.floor(Math.random() * sides.length)];
    $scope.meals.push('meal ' + i + ': ' + dish + ' ' + side);
  }
  
  $scope.pageChangeHandler = function(num) {
      console.log('meals page changed to ' + num);
  };
}

function OtherController($scope) {
  $scope.pageChangeHandler = function(num) {
    console.log('going to page ' + num);
  };
}

VolpayApp.controller('MyController', MyController);
VolpayApp.controller('OtherController', OtherController);
