
TODO
====

* Fix scatterChart: TypeError: chart.scatter.onlyCircles is not a function

* Improve documentation

* Add Django Test in nvd3_tests
